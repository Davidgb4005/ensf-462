import socket

client_name = input("Enter Client Name: ")
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("localhost", 5000))
print("Connected to server")

client.send(client_name.encode())
server_name = client.recv(1024).decode()

while True:
    msg = input(client_name + " > ")
    client.send(msg.encode())
    if msg.lower() == "bye":
        break

    msg = client.recv(1024).decode()
    if not msg:
        break

    print(server_name + " > " + msg)
    if msg.lower() == "bye":
        break

client.close()
print("Client socket closed")
