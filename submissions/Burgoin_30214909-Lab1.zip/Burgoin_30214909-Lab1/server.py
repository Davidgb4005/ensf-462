import socket

server_name = input("Enter Server Name: ")
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(("localhost", 5000))
server.listen(1)
print("Waiting for client")

conn, addr = server.accept()
print("Connected:", addr)

client_name = conn.recv(1024).decode()
conn.send(server_name.encode())

while True:
    msg = conn.recv(1024).decode()
    if not msg:
        break

    print(client_name + " > " + msg)
    if msg.lower() == "bye":
        break

    msg = input(server_name + " > ")
    conn.send(msg.encode())
    if msg.lower() == "bye":
        break

conn.close()
server.close()
print("Server sockets closed")
